const reviews = [
  {
    id: "r001",
    film_id: "f001",
    user_id: "u001",
    username: "user name",
    score: 8.5,
    comment: "comment_review by userid",
  },
  {
    id: "r002",
    film_id: "f001",
    user_id: "u002",
    username: "user name",
    score: 7.0,
    comment: "comment_review by userid",
  },
  {
    id: "r003",
    film_id: "f001",
    user_id: "u003",
    username: "user name",
    score: 9.0,
    comment: "comment_review by userid",
  },
  {
    id: "r004",
    film_id: "f002",
    user_id: "u001",
    username: "user name",
    score: 9.5,
    comment: "comment_review by userid",
  },
  {
    id: "r005",
    film_id: "f003",
    user_id: "u002",
    username: "user name",
    score: 6.0,
    comment: "comment_review by userid",
  }
];

export default reviews;

export const threads = [
  {
    id: 1,
    title: "What movie was so bad it was actually good?",
    author: "User1",
    link: "/forum"
  },
  {
    id: 2,
    title: "Which movie genre do you think has the most impact on pop culture today?",
    author: "User1",
    link: "/forum"
  },
  {
    id: 3,
    title: "Which actor or director has the best filmography right now?",
    author: "User1",
    link: "/forum"
  }
];